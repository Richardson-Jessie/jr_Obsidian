- [ ] Bug With Task List Tool - Follow Up with Northy
	- [ ] Returns Process Issue???
	- [ ] Material Deletion Indicator
	- [ ] New Operations Sorting By APLZL
	- [ ] Fiori not super flexible
- [ ] Follow Up With Jess Tandy Work Flow
- [ ] Finish FSPEC For Table Variants
- [ ] Dom Broom - Kat Bown - Outstanding Work Report
- [ ] Test FFI Pims Links

