Current 
[Work Management KPIs - Fortescue - Reporting (fmgl.com.au)](https://analytics.fmgl.com.au/#/site/published/projects/421)

